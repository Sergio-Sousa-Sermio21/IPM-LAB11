<template>
    <div class="container">
        <div class="row">
            <div class="col-md-6"  style="text-align:left;">
                &copy; 2023 Interfaces Pessoa-M&aacute;quina
            </div>
            <div class="col-md-6" style="text-align:right;">
                Designed by <a href="#">Aluno</a>
            </div>
        </div>
    </div>
</template>

<script>
</script>
